function PostController() {
};

angular.
  module('ShopickApp').
  controller("PostCtrl", PostController).
  component('myPost',  {
	  templateUrl: 'assets/collection/post.template.html.erb',
	  controller: PostController,
  bindings: {
    postarg: '<'
  }
});
